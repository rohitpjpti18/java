package org.cap.controller;

import org.cap.entities.Customer;
import org.cap.service.ICustomerService;
import org.cap.util.SessionData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CustomerController {

    @Autowired
    private ICustomerService service;

    @Autowired
    private SessionData sessionData;

    @GetMapping("/")
    public ModelAndView home(){
       return new ModelAndView("homepage");
    }


    @GetMapping("/register")
    //@RequestMapping(path = "/register",method = RequestMethod.GET)
    public ModelAndView register() {
        ModelAndView mv = new ModelAndView("registercustomer");
        return mv;
    }

    @GetMapping("/processregister")
    public ModelAndView processRegister(@RequestParam("custid") int id,
                                        @RequestParam("custname") String custname,
                                        @RequestParam("password") String password) {
        Customer customer = new Customer();
        customer.setId(id);
        customer.setName(custname);
        customer.setPassword(password);
        service.save(customer);
        ModelAndView mv = new ModelAndView("details", "customer", customer);
        return mv;
    }

    @GetMapping("/details")
    public ModelAndView customerDetails() {
        int id = sessionData.getCustomerID();
        if (id == -1) {
            return new ModelAndView("login");
        }
        Customer customer = service.findCustomerById(id);
        ModelAndView mv = new ModelAndView("details", "customer", customer);
        return mv;
    }

    @GetMapping("/login")
    public ModelAndView loginPage() {
        return new ModelAndView("login");
    }

    @GetMapping("/processlogin")
    public ModelAndView processLogin(@RequestParam("custid") int id, @RequestParam("password") String password) {
        boolean correct = service.credentialsCorrect(id, password);
        if (!correct) {
            return new ModelAndView("login");
        }
        sessionData.setCustomerID(id);
        Customer customer = service.findCustomerById(id);
        ModelAndView mv = new ModelAndView("details", "customer", customer);
        return mv;
    }

    @GetMapping("/logout")
    public ModelAndView logout() {
        sessionData.setCustomerID(-1);
        return new ModelAndView("login");
    }




}
