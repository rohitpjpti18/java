package org.cap.empmgt.controller;

import org.cap.empmgt.dto.EmployeeDto;
import org.cap.empmgt.entities.Employee;
import org.cap.empmgt.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeRestController {

    @Autowired
    private IEmployeeService service;

   @PostMapping("/add")
    public ResponseEntity<Employee>createEmployee(@RequestBody EmployeeDto dto){
        Employee employee=new Employee();
        employee.setName(dto.getName());
        employee=service.save(employee);
        ResponseEntity<Employee>response=new ResponseEntity<>(employee, HttpStatus.OK);
        return response;
   }

   @GetMapping("/get/{id}")
   public ResponseEntity<Employee>findEmployee(@PathVariable("id")int id){
      Employee employee= service.findById(id);
      ResponseEntity<Employee>response=new ResponseEntity<>(employee,HttpStatus.OK);
      return response;
   }

   @GetMapping
   public ResponseEntity<List<Employee>>fetchAll(){
       List<Employee>employees=service.fetchAll();
       ResponseEntity<List<Employee>>response=new ResponseEntity<>(employees,HttpStatus.OK);
       return response;
   }


}
