package org.cap.service;

import org.cap.entities.Customer;

public interface ICustomerService {
    Customer findCustomerById(int id);

    void save(Customer customer);

    boolean credentialsCorrect(int id, String password);
}
