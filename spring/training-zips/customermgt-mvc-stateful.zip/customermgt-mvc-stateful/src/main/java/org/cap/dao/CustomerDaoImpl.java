package org.cap.dao;

import org.cap.entities.Customer;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;

@Repository
public class CustomerDaoImpl implements ICustomerDao {
    private Map<Integer, Customer> store = new HashMap<>();

    @Override
    public Customer findCustomerById(int id) {
        Customer customer = store.get(id);
        return customer;
    }

    @Override
    public void save(Customer customer) {
        store.put(customer.getId(), customer);
    }

    @Override
    public boolean credentialsCorrect(int id, String password){
        if(password==null|| password.isEmpty()){
            return false;
        }
        Customer customer=store.get(id);
        if(customer==null){
          return false;
        }
        boolean passwordEquals=customer.getPassword().equals(password);
        return passwordEquals;
    }
}
