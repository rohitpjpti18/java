package org.cap.empmgt.dto;

public class EmployeeDto {
    private String name;

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name=name;
    }

}
