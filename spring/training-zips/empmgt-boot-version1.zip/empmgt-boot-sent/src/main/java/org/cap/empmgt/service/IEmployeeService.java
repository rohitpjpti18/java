package org.cap.empmgt.service;

import org.cap.empmgt.entities.Employee;

import java.util.List;

public interface IEmployeeService {

    Employee findById(int id);

    Employee save(Employee user);

    List<Employee> fetchAll();
}
