package org.cap.empmgt.dao;

import org.cap.empmgt.entities.Employee;
import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.util.List;

@Repository
public class EmployeeDaoImpl implements IEmployeeDao {

    private EntityManager entityManager;

    public EntityManager getEntityManager() {
        return entityManager;
    }

    @PersistenceContext // @Autowired
    public void setEntityManager(EntityManager entityManager) {
        this.entityManager = entityManager;
    }


    @Override
    public Employee findById(int id) {
        Employee user = entityManager.find(Employee.class, id);
        return user;
    }


    @Override
    public List<Employee>fetchAll(){
        String jql = "from Employee";
        TypedQuery<Employee> query = entityManager.createQuery(jql, Employee.class);
        List<Employee> list = query.getResultList();
        return list;

    }

    @Override
    public Employee save(Employee employee) {
        employee = entityManager.merge(employee);
        return employee;
    }

}
