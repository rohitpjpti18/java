package org.cap.dao;

import org.cap.entities.Customer;

public interface ICustomerDao {

    Customer findCustomerById(int id);

    void save(Customer customer);

    boolean credentialsCorrect(int id, String password);
}
