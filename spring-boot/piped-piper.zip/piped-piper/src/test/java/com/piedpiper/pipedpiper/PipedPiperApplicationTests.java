package com.piedpiper.pipedpiper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PipedPiperApplicationTests {

	@Test
	void contextLoads() {
	}

}
