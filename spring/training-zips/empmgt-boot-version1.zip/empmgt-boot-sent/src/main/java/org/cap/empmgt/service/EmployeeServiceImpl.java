package org.cap.empmgt.service;

import org.cap.empmgt.dao.IEmployeeDao;
import org.cap.empmgt.entities.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {

    private IEmployeeDao employeeDao;

    public IEmployeeDao getEmployeeDao() {
        return employeeDao;
    }

    @Autowired
    public void setEmployeeDao(IEmployeeDao dao) {
        this.employeeDao = dao;
    }

    @Override
    public Employee findById(int id) {
        return employeeDao.findById(id);
    }

    /**
     * spring will open transaction automagically before execution of this method
     */
    @Override
    public Employee save(Employee employee) {
        return employeeDao.save(employee);
    }
    //spring will automatically close the transaction

    @Override
    public List<Employee> fetchAll() {
        return employeeDao.fetchAll();
    }
}
