package org.cap.empmgt.dao;

import org.cap.empmgt.entities.Employee;

import java.util.List;

public interface IEmployeeDao {

    Employee findById(int id);

    Employee save(Employee user);

    List<Employee> fetchAll();

}
